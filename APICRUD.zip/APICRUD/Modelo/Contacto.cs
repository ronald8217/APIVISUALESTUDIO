﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace APICRUD.Modelo
{
    public class Contacto
    {
        public int Id {get; set; }
        public int TipId { get; set; }
        public  String Nombre { get; set; }
        public String Apellido { get; set; }
        public String Contrasena { get; set; }
        [EmailAddress(ErrorMessage = "Escriba mail valido")]
        public String Mail { get; set; }
    }

    
}
