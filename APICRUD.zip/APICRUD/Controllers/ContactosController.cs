﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using APICRUD.Data;
using APICRUD.Modelo;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace APICRUD.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ContactosController : ControllerBase

    {

        private readonly ContactoContexto _context;

        public ContactosController(ContactoContexto contexto)

        {
            _context = contexto;

        }
        [HttpGet]
        public Task<ActionsResult<IEnumerable<Contacto>>> GetcontactoItems()


        {

            return _context.contactoItems.ToList();
           
        }
    }
}