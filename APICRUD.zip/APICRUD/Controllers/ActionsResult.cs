﻿namespace APICRUD.Controllers
{
    public class ActionsResult<T>
    {
    }
}