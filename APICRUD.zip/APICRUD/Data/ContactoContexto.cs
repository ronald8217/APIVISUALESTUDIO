﻿using APICRUD.Modelo;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Threading.Tasks;

namespace APICRUD.Data
{
    public class ContactoContexto : DbContext    
    {
        public ContactoContexto(DbContextOptions<ContactoContexto> options):base(options)
        {
        }
        //crear bdset  copiando en ContactoItems
        
        public DbSet<Contacto> ContactoItems { get;set;}
    }
}
