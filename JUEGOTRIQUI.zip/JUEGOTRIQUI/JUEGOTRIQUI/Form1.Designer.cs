﻿namespace JUEGOTRIQUI
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.a3 = new System.Windows.Forms.Button();
            this.a2 = new System.Windows.Forms.Button();
            this.a1 = new System.Windows.Forms.Button();
            this.b1 = new System.Windows.Forms.Button();
            this.b2 = new System.Windows.Forms.Button();
            this.b3 = new System.Windows.Forms.Button();
            this.c1 = new System.Windows.Forms.Button();
            this.c2 = new System.Windows.Forms.Button();
            this.c3 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnLIMPIAR = new System.Windows.Forms.Button();
            this.btnREINICIAR = new System.Windows.Forms.Button();
            this.btnINICIAR = new System.Windows.Forms.Button();
            this.txtJugador2 = new System.Windows.Forms.TextBox();
            this.txtJugador1 = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.rbtnJugador2o = new System.Windows.Forms.RadioButton();
            this.rbtnJugador2x = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.rbtnJugador1o = new System.Windows.Forms.RadioButton();
            this.rbtnJugador1x = new System.Windows.Forms.RadioButton();
            this.lblJugador2 = new System.Windows.Forms.Label();
            this.lblJugador1 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // a3
            // 
            this.a3.Location = new System.Drawing.Point(233, 3);
            this.a3.Name = "a3";
            this.a3.Size = new System.Drawing.Size(105, 90);
            this.a3.TabIndex = 0;
            this.a3.UseVisualStyleBackColor = true;
            this.a3.Click += new System.EventHandler(this.Buttons_Click);
            // 
            // a2
            // 
            this.a2.Location = new System.Drawing.Point(121, 3);
            this.a2.Name = "a2";
            this.a2.Size = new System.Drawing.Size(105, 90);
            this.a2.TabIndex = 1;
            this.a2.UseVisualStyleBackColor = true;
            this.a2.Click += new System.EventHandler(this.Buttons_Click);
            // 
            // a1
            // 
            this.a1.Location = new System.Drawing.Point(8, 3);
            this.a1.Name = "a1";
            this.a1.Size = new System.Drawing.Size(105, 90);
            this.a1.TabIndex = 2;
            this.a1.UseVisualStyleBackColor = true;
            this.a1.Click += new System.EventHandler(this.Buttons_Click);
            // 
            // b1
            // 
            this.b1.Location = new System.Drawing.Point(8, 99);
            this.b1.Name = "b1";
            this.b1.Size = new System.Drawing.Size(105, 90);
            this.b1.TabIndex = 3;
            this.b1.UseVisualStyleBackColor = true;
            this.b1.Click += new System.EventHandler(this.Buttons_Click);
            // 
            // b2
            // 
            this.b2.Location = new System.Drawing.Point(121, 99);
            this.b2.Name = "b2";
            this.b2.Size = new System.Drawing.Size(105, 90);
            this.b2.TabIndex = 4;
            this.b2.UseVisualStyleBackColor = true;
            this.b2.Click += new System.EventHandler(this.Buttons_Click);
            // 
            // b3
            // 
            this.b3.Location = new System.Drawing.Point(233, 99);
            this.b3.Name = "b3";
            this.b3.Size = new System.Drawing.Size(105, 90);
            this.b3.TabIndex = 5;
            this.b3.UseVisualStyleBackColor = true;
            this.b3.Click += new System.EventHandler(this.Buttons_Click);
            // 
            // c1
            // 
            this.c1.Location = new System.Drawing.Point(8, 195);
            this.c1.Name = "c1";
            this.c1.Size = new System.Drawing.Size(105, 90);
            this.c1.TabIndex = 6;
            this.c1.UseVisualStyleBackColor = true;
            this.c1.Click += new System.EventHandler(this.Buttons_Click);
            // 
            // c2
            // 
            this.c2.Location = new System.Drawing.Point(121, 195);
            this.c2.Name = "c2";
            this.c2.Size = new System.Drawing.Size(105, 90);
            this.c2.TabIndex = 7;
            this.c2.UseVisualStyleBackColor = true;
            this.c2.Click += new System.EventHandler(this.Buttons_Click);
            // 
            // c3
            // 
            this.c3.Location = new System.Drawing.Point(233, 195);
            this.c3.Name = "c3";
            this.c3.Size = new System.Drawing.Size(105, 90);
            this.c3.TabIndex = 8;
            this.c3.UseVisualStyleBackColor = true;
            this.c3.Click += new System.EventHandler(this.Buttons_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel1.Controls.Add(this.a1);
            this.panel1.Controls.Add(this.a2);
            this.panel1.Controls.Add(this.c1);
            this.panel1.Controls.Add(this.c3);
            this.panel1.Controls.Add(this.b1);
            this.panel1.Controls.Add(this.b3);
            this.panel1.Controls.Add(this.a3);
            this.panel1.Controls.Add(this.c2);
            this.panel1.Controls.Add(this.b2);
            this.panel1.Location = new System.Drawing.Point(72, 32);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(346, 292);
            this.panel1.TabIndex = 9;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.btnLIMPIAR);
            this.groupBox1.Controls.Add(this.btnREINICIAR);
            this.groupBox1.Controls.Add(this.btnINICIAR);
            this.groupBox1.Controls.Add(this.txtJugador2);
            this.groupBox1.Controls.Add(this.txtJugador1);
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.lblJugador2);
            this.groupBox1.Controls.Add(this.lblJugador1);
            this.groupBox1.Controls.Add(this.pictureBox2);
            this.groupBox1.Controls.Add(this.pictureBox1);
            this.groupBox1.Location = new System.Drawing.Point(542, 25);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(233, 370);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Nombres Jugadores";
            // 
            // btnLIMPIAR
            // 
            this.btnLIMPIAR.Location = new System.Drawing.Point(6, 341);
            this.btnLIMPIAR.Name = "btnLIMPIAR";
            this.btnLIMPIAR.Size = new System.Drawing.Size(87, 23);
            this.btnLIMPIAR.TabIndex = 10;
            this.btnLIMPIAR.Text = "LIMPIAR";
            this.btnLIMPIAR.UseVisualStyleBackColor = true;
            this.btnLIMPIAR.Visible = false;
            this.btnLIMPIAR.Click += new System.EventHandler(this.btnLIMPIAR_Click);
            // 
            // btnREINICIAR
            // 
            this.btnREINICIAR.Location = new System.Drawing.Point(146, 341);
            this.btnREINICIAR.Name = "btnREINICIAR";
            this.btnREINICIAR.Size = new System.Drawing.Size(87, 23);
            this.btnREINICIAR.TabIndex = 9;
            this.btnREINICIAR.Text = "REINICIAR";
            this.btnREINICIAR.UseVisualStyleBackColor = true;
            this.btnREINICIAR.Visible = false;
            this.btnREINICIAR.Click += new System.EventHandler(this.btnREINICIAR_Click);
            // 
            // btnINICIAR
            // 
            this.btnINICIAR.Location = new System.Drawing.Point(76, 341);
            this.btnINICIAR.Name = "btnINICIAR";
            this.btnINICIAR.Size = new System.Drawing.Size(87, 23);
            this.btnINICIAR.TabIndex = 8;
            this.btnINICIAR.Text = "INICIAR";
            this.btnINICIAR.UseVisualStyleBackColor = true;
            this.btnINICIAR.Click += new System.EventHandler(this.btnINICIAR_Click);
            // 
            // txtJugador2
            // 
            this.txtJugador2.Location = new System.Drawing.Point(65, 307);
            this.txtJugador2.Name = "txtJugador2";
            this.txtJugador2.Size = new System.Drawing.Size(116, 20);
            this.txtJugador2.TabIndex = 7;
            // 
            // txtJugador1
            // 
            this.txtJugador1.Location = new System.Drawing.Point(65, 166);
            this.txtJugador1.Name = "txtJugador1";
            this.txtJugador1.Size = new System.Drawing.Size(116, 20);
            this.txtJugador1.TabIndex = 6;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.rbtnJugador2o);
            this.groupBox3.Controls.Add(this.rbtnJugador2x);
            this.groupBox3.Location = new System.Drawing.Point(65, 265);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(117, 36);
            this.groupBox3.TabIndex = 5;
            this.groupBox3.TabStop = false;
            // 
            // rbtnJugador2o
            // 
            this.rbtnJugador2o.AutoSize = true;
            this.rbtnJugador2o.Location = new System.Drawing.Point(7, 12);
            this.rbtnJugador2o.Name = "rbtnJugador2o";
            this.rbtnJugador2o.Size = new System.Drawing.Size(32, 17);
            this.rbtnJugador2o.TabIndex = 1;
            this.rbtnJugador2o.TabStop = true;
            this.rbtnJugador2o.Text = "o";
            this.rbtnJugador2o.UseVisualStyleBackColor = true;
            // 
            // rbtnJugador2x
            // 
            this.rbtnJugador2x.AutoSize = true;
            this.rbtnJugador2x.Location = new System.Drawing.Point(62, 12);
            this.rbtnJugador2x.Name = "rbtnJugador2x";
            this.rbtnJugador2x.Size = new System.Drawing.Size(31, 17);
            this.rbtnJugador2x.TabIndex = 0;
            this.rbtnJugador2x.TabStop = true;
            this.rbtnJugador2x.Text = "x";
            this.rbtnJugador2x.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.rbtnJugador1o);
            this.groupBox2.Controls.Add(this.rbtnJugador1x);
            this.groupBox2.Location = new System.Drawing.Point(65, 121);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(117, 35);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            // 
            // rbtnJugador1o
            // 
            this.rbtnJugador1o.AutoSize = true;
            this.rbtnJugador1o.Location = new System.Drawing.Point(7, 12);
            this.rbtnJugador1o.Name = "rbtnJugador1o";
            this.rbtnJugador1o.Size = new System.Drawing.Size(32, 17);
            this.rbtnJugador1o.TabIndex = 1;
            this.rbtnJugador1o.TabStop = true;
            this.rbtnJugador1o.Text = "o";
            this.rbtnJugador1o.UseVisualStyleBackColor = true;
            // 
            // rbtnJugador1x
            // 
            this.rbtnJugador1x.AutoSize = true;
            this.rbtnJugador1x.Location = new System.Drawing.Point(62, 12);
            this.rbtnJugador1x.Name = "rbtnJugador1x";
            this.rbtnJugador1x.Size = new System.Drawing.Size(31, 17);
            this.rbtnJugador1x.TabIndex = 0;
            this.rbtnJugador1x.TabStop = true;
            this.rbtnJugador1x.Text = "x";
            this.rbtnJugador1x.UseVisualStyleBackColor = true;
            // 
            // lblJugador2
            // 
            this.lblJugador2.AutoSize = true;
            this.lblJugador2.Location = new System.Drawing.Point(103, 249);
            this.lblJugador2.Name = "lblJugador2";
            this.lblJugador2.Size = new System.Drawing.Size(59, 13);
            this.lblJugador2.TabIndex = 3;
            this.lblJugador2.Text = "Jugador2";
            // 
            // lblJugador1
            // 
            this.lblJugador1.AutoSize = true;
            this.lblJugador1.Location = new System.Drawing.Point(103, 105);
            this.lblJugador1.Name = "lblJugador1";
            this.lblJugador1.Size = new System.Drawing.Size(59, 13);
            this.lblJugador1.TabIndex = 2;
            this.lblJugador1.Text = "Jugador1";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::JUEGOTRIQUI.Properties.Resources.jugador2;
            this.pictureBox2.Location = new System.Drawing.Point(65, 192);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(117, 50);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::JUEGOTRIQUI.Properties.Resources.jugador1;
            this.pictureBox1.Location = new System.Drawing.Point(65, 46);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(117, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.25F);
            this.label1.Location = new System.Drawing.Point(206, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 25);
            this.label1.TabIndex = 11;
            this.label1.Text = "TRIQUI";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::JUEGOTRIQUI.Properties.Resources.FONDO;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(831, 407);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button a3;
        private System.Windows.Forms.Button a2;
        private System.Windows.Forms.Button a1;
        private System.Windows.Forms.Button b1;
        private System.Windows.Forms.Button b2;
        private System.Windows.Forms.Button b3;
        private System.Windows.Forms.Button c1;
        private System.Windows.Forms.Button c2;
        private System.Windows.Forms.Button c3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblJugador2;
        private System.Windows.Forms.Label lblJugador1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnINICIAR;
        private System.Windows.Forms.TextBox txtJugador2;
        private System.Windows.Forms.TextBox txtJugador1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RadioButton rbtnJugador2o;
        private System.Windows.Forms.RadioButton rbtnJugador2x;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton rbtnJugador1o;
        private System.Windows.Forms.RadioButton rbtnJugador1x;
        private System.Windows.Forms.Button btnLIMPIAR;
        private System.Windows.Forms.Button btnREINICIAR;
    }
}

