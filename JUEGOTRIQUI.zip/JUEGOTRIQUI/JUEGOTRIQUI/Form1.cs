﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JUEGOTRIQUI
{
   
    public partial class Form1 : Form
    {
        string jugadorO = "";
        string jugadorX = "";
        bool cambio = true;
        int empate = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            OnOffBtn(false);
        }

        private void OnOffBtn(bool onoff)
        {
            a1.Enabled = onoff;
            a2.Enabled = onoff;
            a3.Enabled = onoff;
            b1.Enabled = onoff;
            b2.Enabled = onoff;
            b3.Enabled = onoff;
            c1.Enabled = onoff;
            c2.Enabled = onoff;
            c3.Enabled = onoff;
        }

        private void btnINICIAR_Click(object sender, EventArgs e)
        {
            Ingresar();
        }

        private void Ingresar()
        {
            if(txtJugador1.Text =="" && txtJugador2.Text == "")
            {
                MessageBox.Show("El nombre de los jugadores no debe de estar vacio", "Nombre no valido", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                if (txtJugador1.Text == "")
                {
                    MessageBox.Show("El nombre del jugador1 no debe de estar vacio", "Nombre no valido", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                if (txtJugador1.Text == "")
                {
                    MessageBox.Show("El nombre del jugador2 no debe de estar vacio", "Nombre no valido", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }

            if (txtJugador1.Text != "" && txtJugador2.Text !="")
            {
                if (rbtnJugador1o.Checked && rbtnJugador1x.Checked)
                {
                    jugadorO = txtJugador1.Text;
                    jugadorX = txtJugador2.Text;
                    rbtnJugador1o.Enabled = false;
                    rbtnJugador2x.Enabled = false;
                    PlayGame();
                }
                if (rbtnJugador1x.Checked && rbtnJugador1o.Checked)
                {
                    jugadorO = txtJugador2.Text;
                    jugadorX = txtJugador1.Text;
                    rbtnJugador1x.Enabled = false;
                    rbtnJugador2o.Enabled = false;
                    PlayGame();
                }

                if (rbtnJugador1o.Checked && rbtnJugador2o.Checked)
                {
                    MessageBox.Show("Solo un jugador puede seleccionar la letra o", "vuelva a seleccionar", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                if (rbtnJugador1x.Checked && rbtnJugador2x.Checked)
                {
                    MessageBox.Show("Solo un jugador puede seleccionar la letra +", "vuelva a seleccionar", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                if (rbtnJugador1o.Checked == false && rbtnJugador1x.Checked == false || rbtnJugador2o.Checked == false && rbtnJugador2x.Checked == false)
                {
                    MessageBox.Show("Los jugadores deben seleccionar una letra ", "vuelva a seleccionar", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    
                }

                lblJugador1.Text = txtJugador1.Text;
                lblJugador2.Text = txtJugador2.Text;

                btnLIMPIAR.Visible = true;
                btnREINICIAR.Visible = true;

                btnINICIAR.Visible = false;
                txtJugador1.Visible = false;
                txtJugador2.Visible = false;

                MessageBox.Show("Empieza el juego " , "Informacion", MessageBoxButtons.OK, MessageBoxIcon.Information);

                OnOffBtn(true);

            }

        }

        private void PlayGame()
        {
            lblJugador1.Text = txtJugador1.Text;
            lblJugador2.Text = txtJugador2.Text;

            groupBox1.Text = "Marcador";

            btnLIMPIAR.Visible = true;
            btnREINICIAR.Visible = true;

            btnINICIAR.Visible = false;
            txtJugador1.Visible = false;
            txtJugador2.Visible = false;

            MessageBox.Show("Empieza el jugador " + jugadorO, "Informacion", MessageBoxButtons.OK, MessageBoxIcon.Information);
            OnOffBtn(true);
        }

        private void Buttons_Click(object sender, EventArgs e)
        {
            Button b = (Button)sender;

            if (cambio)
            {
                b.Text = "x";
            }
            else
            {
                b.Text = "o";
            }

            cambio = !cambio;
            b.Enabled = false;
            Partida();
        }

        private void Partida()
        {
            if ((a1.Text == a2.Text) && (a2.Text == a3.Text) && (!a1.Enabled))
            {
                MessageBox.Show("Ganador");
            }
            else if ((b1.Text == b2.Text) && (b2.Text == b3.Text) && (!b1.Enabled))
            {
                MessageBox.Show("Ganador");
            }

            else if ((c1.Text == c2.Text) && (c2.Text == c3.Text) && (!c1.Enabled))
            {
                MessageBox.Show("Ganador");
            }

            if ((a1.Text == b1.Text) && (b1.Text == c1.Text) && (!a1.Enabled))
            {
                MessageBox.Show("Ganador");
            }
            else if ((a2.Text == b2.Text) && (b2.Text == c2.Text) && (!a2.Enabled))
            {
                MessageBox.Show("Ganador");
            }

            if ((a3.Text == b3.Text) && (b3.Text == c3.Text) && (!a3.Enabled))
            {
                MessageBox.Show("Ganador");
            }

            if ((a1.Text == b2.Text) && (b2.Text == c3.Text) && (!a1.Enabled))
            {
                MessageBox.Show("Ganador");
            }
            else if ((a3.Text == b2.Text) && (b2.Text == c1.Text) && (!a3.Enabled))
            {
                MessageBox.Show("Ganador");
            }

            empate++;

            if (empate ==9)
            {
                MessageBox.Show("Es un Empate " , "Empate", MessageBoxButtons.OK, MessageBoxIcon.Information);

                Limpiar();
                OnOffBtn(true);
                empate = 0;
            }
        }

        private void Limpiar()
        {
            a1.Text = "";
            a2.Text = "";
            a3.Text = "";
            b1.Text = "";
            b2.Text = "";
            b3.Text = "";
            c1.Text = "";
            c2.Text = "";
            c3.Text = "";
        }

        private void btnLIMPIAR_Click(object sender, EventArgs e)
        {
            Limpiar();
            OnOffBtn(true);
            empate = 0;
        }

        private void btnREINICIAR_Click(object sender, EventArgs e)
        {
            Limpiar();
            OnOffBtn(false);
            btnLIMPIAR.Visible = false;
            btnREINICIAR.Visible = false;

            btnINICIAR.Visible = true;
            txtJugador1.Visible = true;
            txtJugador2.Visible = true;

      
            jugadorO = "";
            jugadorX = "";

            lblJugador1.Text = "";
            lblJugador2.Text = "";
            txtJugador1.Text = "";
            txtJugador2.Text = "";

            rbtnJugador1o.Enabled = true;
            rbtnJugador2x.Enabled = true;
            rbtnJugador1x.Enabled = true;
            rbtnJugador2o.Enabled = true;

            rbtnJugador1o.Checked = false;
            rbtnJugador2x.Checked = false;
            rbtnJugador1x.Checked = false;
            rbtnJugador2o.Checked = false;
            
        }
    }
}
